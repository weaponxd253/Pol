import Phaser from 'phaser';

const WIDTH = 960;
const HEIGHT = 720;
const WALK_SPEED = 165;

// Coordinates use the 960x720 room, not the original 1448x1086 PNG.
// These are approximate furniture footprints, intended to be adjusted with the C debug key.
const OBSTACLES = [
  { x: 33, y: 69, w: 135, h: 257 }, // bookshelves
  { x: 751, y: 66, w: 149, h: 169 }, // file cabinet
  { x: 357, y: 207, w: 227, h: 120 }, // executive desk
  { x: 433, y: 182, w: 61, h: 57 }, // executive chair (merged with desk footprint)
  { x: 313, y: 366, w: 86, h: 153 }, // left sofa
  { x: 548, y: 365, w: 77, h: 156 }, // right sofa
  { x: 425, y: 395, w: 83, h: 109 }, // coffee table
  { x: 437, y: 502, w: 77, h: 66 }, // front guest chair
  { x: 758, y: 305, w: 116, h: 200 }, // briefing table and seats
  { x: 70, y: 376, w: 62, h: 164 }, // sideboard
  { x: 36, y: 514, w: 59, h: 83 }, // left plant
  { x: 860, y: 508, w: 58, h: 85 }, // right plant
];

const INTERACTIONS = [
  { name: 'National Policy Desk', x: 480, y: 347, radius: 70, action: 'national-policies', description: 'Open the existing policy and executive decision system.' },
  { name: 'Cabinet Briefing Table', x: 720, y: 421, radius: 68, action: 'cabinet-briefing', description: 'Open reports, cabinet briefings, and government priorities.' },
  { name: 'Government Archives', x: 202, y: 205, radius: 69, action: 'archives', description: 'Open the decision history, archives, or intelligence records.' },
  { name: 'Advisor Meeting Area', x: 479, y: 588, radius: 56, action: 'advisors', description: 'Open advisor conversations and events.' },
  { name: 'Office Door', x: 480, y: 662, radius: 52, action: 'exit-office', description: 'Return to the main government dashboard or map.' },
];

const dialog = document.getElementById('office-dialog');
const dialogTitle = document.getElementById('dialog-title');
const dialogDescription = document.getElementById('dialog-description');
const closeButton = document.getElementById('close-dialog');

function closeDialog() { dialog.hidden = true; }
closeButton.addEventListener('click', closeDialog);
document.addEventListener('keydown', (event) => {
  if (event.key === 'Escape') closeDialog();
});

class OfficeScene extends Phaser.Scene {
  constructor() {
    super('OfficeScene');
    this.lastDirection = 'up';
    this.nearby = null;
  }

  preload() {
    this.load.image('office', '/assets/office.png');
    this.load.spritesheet('leader', '/assets/leader_spritesheet.png', {
      frameWidth: 192,
      frameHeight: 288,
    });
  }

  create() {
    this.add.image(WIDTH / 2, HEIGHT / 2, 'office').setDisplaySize(WIDTH, HEIGHT);

    // Four rows: down: 0..3, left: 4..7, right: 8..11, up: 12..15.
    for (const [direction, start] of Object.entries({ down: 0, left: 4, right: 8, up: 12 })) {
      this.anims.create({
        key: `walk-${direction}`,
        frames: this.anims.generateFrameNumbers('leader', {
          frames: [start + 1, start + 2, start + 3, start + 2],
        }),
        frameRate: 7,
        repeat: -1,
      });
    }

    // Character coordinates are anchored to the feet, for easy furniture collisions.
    this.player = this.add.sprite(480, 610, 'leader', 12)
      .setOrigin(0.5, 0.98)
      .setScale(0.25)
      .setDepth(10);

    this.cursors = this.input.keyboard.createCursorKeys();
    this.keys = this.input.keyboard.addKeys({
      w: Phaser.Input.Keyboard.KeyCodes.W,
      a: Phaser.Input.Keyboard.KeyCodes.A,
      s: Phaser.Input.Keyboard.KeyCodes.S,
      d: Phaser.Input.Keyboard.KeyCodes.D,
      e: Phaser.Input.Keyboard.KeyCodes.E,
      c: Phaser.Input.Keyboard.KeyCodes.C,
    });

    this.hint = this.add.text(WIDTH / 2, 712, '', {
      fontFamily: 'Arial, sans-serif', fontSize: '17px', color: '#fff8e9',
      backgroundColor: '#162c24', padding: { x: 12, y: 8 },
    }).setOrigin(0.5, 1).setDepth(30);

    this.debugGraphics = this.add.graphics().setDepth(25).setVisible(false);
    this.debugGraphics.lineStyle(2, 0xff3636, 0.88);
    this.debugGraphics.fillStyle(0xff3434, 0.12);
    for (const obstacle of OBSTACLES) {
      this.debugGraphics.fillRect(obstacle.x, obstacle.y, obstacle.w, obstacle.h);
      this.debugGraphics.strokeRect(obstacle.x, obstacle.y, obstacle.w, obstacle.h);
    }
    this.debugGraphics.lineStyle(2, 0x35fff3, 0.88);
    for (const action of INTERACTIONS) {
      this.debugGraphics.strokeCircle(action.x, action.y, action.radius);
    }

    this.input.keyboard.on('keydown-C', () => {
      this.debugGraphics.setVisible(!this.debugGraphics.visible);
    });
    this.input.keyboard.on('keydown-E', () => {
      if (dialog.hidden && this.nearby) this.openInteraction(this.nearby);
    });
  }

  blocked(x, y) {
    // Keep the player on the floor. Allow the lower center doorway to be approached.
    const bottom = x >= 422 && x <= 525 ? 673 : 633;
    if (x < 28 || x > 930 || y < 51 || y > bottom) return true;

    // The collision point is the character's feet, with a small horizontal radius.
    const radiusX = 11;
    const radiusY = 6;
    return OBSTACLES.some(o =>
      x > o.x - radiusX && x < o.x + o.w + radiusX &&
      y > o.y - radiusY && y < o.y + o.h + radiusY
    );
  }

  update(_time, delta) {
    if (!dialog.hidden) {
      this.player.anims.stop();
      this.player.setFrame(({ down: 0, left: 4, right: 8, up: 12 })[this.lastDirection]);
      return;
    }

    let dx = Number(this.cursors.right.isDown || this.keys.d.isDown) - Number(this.cursors.left.isDown || this.keys.a.isDown);
    let dy = Number(this.cursors.down.isDown || this.keys.s.isDown) - Number(this.cursors.up.isDown || this.keys.w.isDown);
    const moving = dx !== 0 || dy !== 0;

    if (moving) {
      const magnitude = Math.hypot(dx, dy);
      dx /= magnitude;
      dy /= magnitude;
      const distance = WALK_SPEED * Math.min(delta, 50) / 1000;
      if (!this.blocked(this.player.x + dx * distance, this.player.y)) this.player.x += dx * distance;
      if (!this.blocked(this.player.x, this.player.y + dy * distance)) this.player.y += dy * distance;
      this.lastDirection = Math.abs(dx) > Math.abs(dy) ? (dx > 0 ? 'right' : 'left') : (dy > 0 ? 'down' : 'up');
      this.player.anims.play(`walk-${this.lastDirection}`, true);
    } else {
      this.player.anims.stop();
      this.player.setFrame(({ down: 0, left: 4, right: 8, up: 12 })[this.lastDirection]);
    }

    // Find the closest reachable hotspot rather than assuming a fixed action key target.
    const candidates = INTERACTIONS.map(i => ({ ...i, distance: Phaser.Math.Distance.Between(this.player.x, this.player.y, i.x, i.y) }))
      .filter(i => i.distance <= i.radius)
      .sort((a, b) => a.distance - b.distance);
    this.nearby = candidates[0] ?? null;
    this.hint.setText(this.nearby ? `E  ·  ${this.nearby.name}` : '');
  }

  openInteraction(interaction) {
    // In the actual government game, catch this event and call the existing menu function.
    window.dispatchEvent(new CustomEvent('government:office-action', {
      detail: { action: interaction.action, name: interaction.name },
    }));

    // Demo-only fallback modal. Remove this when the existing game owns the interaction.
    dialogTitle.textContent = interaction.name;
    dialogDescription.textContent = interaction.description;
    dialog.hidden = false;
    closeButton.focus();
  }
}

new Phaser.Game({
  type: Phaser.AUTO,
  parent: 'game',
  width: WIDTH,
  height: HEIGHT,
  backgroundColor: '#18241b',
  pixelArt: true,
  roundPixels: true,
  scale: { mode: Phaser.Scale.FIT, autoCenter: Phaser.Scale.CENTER_BOTH },
  scene: [OfficeScene],
});
