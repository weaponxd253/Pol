# Government Executive Office – Phaser 3 starter

An independent demo scene for integrating the generated executive office and character assets with an existing menu-based government strategy game. It does **not** replace existing simulation code.

## Run

Requires Node.js and npm:

```bash
npm install
npm run dev
```

Open the localhost URL displayed by Vite (usually http://127.0.0.1:5173/).

## Controls

- WASD / arrow keys: move
- E: interact with nearby object
- C: show/hide approximate furniture collision boxes (red) and interaction zones (cyan)
- Escape: close the demo interaction popup

## Files

- `public/assets/office.png` — 1448 × 1086 opaque room artwork, rendered at 960 × 720
- `public/assets/leader_spritesheet.png` — normalized 768 × 1152 transparent sprite sheet, 4×4 frames of 192 × 288 pixels
- `main.js` — Phaser scene, directional animations, interaction zones and rudimentary obstacle blocking

Sprite direction rows: down (frames 0–3), left (4–7), right (8–11), up (12–15). First frame of each row is idle. Display scale is 0.25, making each frame 48 × 72 on-screen.

## Connecting to the existing game

The scene emits a browser event whenever the player presses E at an interaction point:

```js
window.addEventListener('government:office-action', (event) => {
  switch (event.detail.action) {
    case 'national-policies':
      // Call the existing 'policy' menu function, route or panel.
      break;
    case 'cabinet-briefing':
      // Call the existing cabinet and reports screen.
      break;
    case 'archives':
      // Call the existing policy history / archives screen.
      break;
    case 'advisors':
      // Call the existing advisors / events screen.
      break;
    case 'exit-office':
      // Return to the original dashboard without resetting game state.
      break;
  }
});
```

These are placeholder action names. Map them to your actual code after inspecting the existing `main.js`, `view.js`, `engine.js`, and `content.js`.

Once wired, remove the `dialogTitle`/`dialogDescription`/`dialog.hidden = false` demo fallback from `openInteraction()` so pressing E opens the real game panel.

**Known limitations:** The artwork is a single flattened image, so the character is drawn above all existing furniture. Realistic furniture occlusion would require exporting foreground sprites or masks. Collision rectangles are approximations and should be tested using `C`. UI integration has not been implemented because the original strategy game source files are not in this starter.
